


var ngApp = angular.module('ngApp', []); 
ngApp.controller('ngAppController', ['$scope','$http', function($scope,$http ) {
	
	var appCtrl =this;
	$scope.keyword="";
	
	$scope.filterItems = [];
	
	  	
//  	{
//		  "master_id": "00001",
//		  "name": "1guitar",
//		  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
//	},{
//		  "master_id": "00002",
//		  "name": "2guitar",
//		  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
//	},{
//		  "master_id": "00003",
//		  "name": "3guitar",
//		  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
//	},{
//		  "master_id": "00004",
//		  "name": "4guitar",
//		  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
//	},{
//		  "master_id": "00005",
//		  "name": "5guitar",
//		  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
//	},{
//		  "master_id": "00006",
//		  "name": "6guitar",
//		  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
//	}
				
				
		
	$scope.init = function ($scope) {
	    $scope.filterItems = [];//angular.copy($scope.allItems);
    };
		
		
		
			
			
				
		
	$scope.searchItem = function (keyword) {
		if(keyword==undefined || keyword.length==0) {alert('至少輸入一個字元查詢項目'); return;};
		
		
		$http.get('/ForestFriends/SearchServlet?keyword='+keyword).
        then(function(response) {
            $scope.filterItems = response.data;
        });
		return;
		
	    
    };
		
		
 
 
 
}]);
