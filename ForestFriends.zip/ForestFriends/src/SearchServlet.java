import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * Servlet implementation class DemoServlet
 */
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String keyword = request.getParameter("keyword");
		System.out.println("[SearchServlet]keyword="+keyword);
		/*		
		List<ItemVo> items=new ArrayList<ItemVo>();
		items =new Gson().fromJson("[" +
									"				{				  \"master_id\": \"00001\",				  \"name\": \"1guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_0_0.png\"			},{				  \"master_id\": \"00002\",				  \"name\": \"2guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_0_0.png\"			},{				  \"master_id\": \"00003\",				  \"name\": \"3guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_0_0.png\"			},{				  \"master_id\": \"00004\",				  \"name\": \"4guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_0_0.png\"			},{				  \"master_id\": \"00005\",				  \"name\": \"5guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_0_0.png\"			},{				  \"master_id\": \"00006\",				  \"name\": \"6guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_0_0.png\"			}" +
									",              {				  \"master_id\": \"00021\",				  \"name\": \"12guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_1_0.png\"			},{				  \"master_id\": \"00022\",				  \"name\": \"22guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_1_0.png\"			},{				  \"master_id\": \"00023\",				  \"name\": \"32guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_1_0.png\"			},{				  \"master_id\": \"00024\",				  \"name\": \"42guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_1_0.png\"			},{				  \"master_id\": \"00025\",				  \"name\": \"52guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_1_0.png\"			},{				  \"master_id\": \"00026\",				  \"name\": \"62guitar\",				  \"image\": \"./img/FtrAcorsticguitar_Remake_1_0.png\"			}" +
									"]",  new TypeToken<List<ItemVo>>(){}.getType() );
		*/
		List<ItemVo> filterItems=new ArrayList<ItemVo>();// from dao
		
		/*
		for(ItemVo item:items ){
			if(item.getMaster_id().toLowerCase().indexOf(keyword.toLowerCase())>-1 ) {filterItems.add(item);}
			if(item.getName().toLowerCase().indexOf(keyword.toLowerCase())>-1 ) {filterItems.add(item);}
		}
		*/
		
		String jsonString = new Gson().toJson(filterItems);
		System.out.println("[SearchServlet]keyword="+keyword+",result==>"+jsonString);
		PrintWriter out = response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		out.print(jsonString);
		out.flush();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
