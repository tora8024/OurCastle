var ngApp = angular.module('ngApp', []); 
ngApp.controller('ngAppController', ['$scope', function($scope) {
	
	var appCtrl =this;
	$scope.keyword="";
	$scope.userId="";
	$scope.myCart=[];
	
	$scope.filterItems = [];
	$scope.hideItemView=false;
	$scope.hideCartView=true;
	
	
  	$scope.allItems = [{
				  "master_id": "00001",
				  "group_name": "Musical instrument",
				  "name": "guitar",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue2",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "00002",
				  "group_name": "Musical instrument",
				  "name": "guitar2",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "00003",
				  "group_name": "Musical instrument",
				  "name": "guitar3",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "00004",
				  "group_name": "Musical instrument",
				  "name": "guitar4",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "00005",
				  "group_name": "Musical instrument",
				  "name": "guitar5",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "00006",
				  "group_name": "Musical instrument",
				  "name": "guitar6",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "00007",
				  "group_name": "Musical instrument",
				  "name": "guitar7",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "00008",
				  "group_name": "Musical instrument",
				  "name": "guitar8",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "00009",
				  "group_name": "Musical instrument",
				  "name": "guitar9",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "000010",
				  "group_name": "Musical instrument",
				  "name": "guitar10",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "000011",
				  "group_name": "Musical instrument",
				  "name": "guitar11",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "000012",
				  "group_name": "Musical instrument",
				  "name": "guitar12",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				,{
				  "master_id": "000013",
				  "group_name": "Musical instrument",
				  "name": "guitar13",
				  "desc": "test",
				  "price": "3210",
				  "styles": [
				    {
				      "detail_id": "1",
				      "name": "brown",
				      "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
				    },
				    {
				      "detail_id": "2",
				      "name": "blue",
				      "image": "./img/FtrAcorsticguitar_Remake_1_0.png"
				    },
				    {
				      "detail_id": "3",
				      "name": "red",
				      "image": "./img/FtrAcorsticguitar_Remake_3_0.png"
				    }
				  ]
				}
				]; 
				
				
		
	$scope.init = function ($scope) {
	    $scope.filterItems = angular.copy($scope.allItems);
    };
		
		
		
	$scope.getTotalPrice = function () {
		var totalPrice = 0;
		for(var i =0 ;i <$scope.myCart.length;i++){	
			totalPrice = totalPrice +  $scope.myCart[i].amount * $scope.myCart[i].price;  
		}
		return totalPrice ;
    };
		
	$scope.deleteItem = function ($event, item) {
		
		var newMyCart=[];
		var primary_key=item.primary_key;
		for(var i =0 ;i <$scope.myCart.length;i++){
			if(primary_key==$scope.myCart[i].primary_key){
				continue;
			}
			newMyCart.push($scope.myCart[i]);
		}
		$scope.myCart = angular.copy(newMyCart);
		
    };
		
	
	$scope.ok = function ($event, item) {
		alert('not yet');
    };
    
    
	$scope.cancel = function ($event, item) {
		alert('not yet');
    };
		
			
	$scope.addToCart = function ($event, item) {
		
		
		var master_id = item.master_id;
		var group_name = item.group_name;
		var name = item.name;
		var desc = item.desc;
		var price =item.price;
		
		var objId = '#'+item.master_id;
		var styleIndex = $(objId).find('li.active').index();
		
				
		var detail_id = item.styles[styleIndex].detail_id;
		var detail_name = item.styles[styleIndex].name;
		var detail_image = item.styles[styleIndex].image;
		var primary_key=master_id+'_'+detail_id;
		
		var order={
				  "primary_key": primary_key,
				  "master_id": master_id,
				  "group_name": group_name,
				  "name": name,
				  "desc": desc,
				  "price": price,
			      "detail_id": detail_id,
			      "detail_name": detail_name,
			      "detail_image": detail_image,
			      "amount": 1
			};
		
		
		
		if ($scope.myCart.length ==0){
			$scope.myCart.push(order);
		}else{
			
			var isMatch=false;
			for(var i =0 ;i <$scope.myCart.length;i++){
				if(primary_key==$scope.myCart[i].primary_key){
					$scope.myCart[i].amount=$scope.myCart[i].amount +1;
					isMatch=true;
					break;
				}
			}
			if(isMatch==false){
				$scope.myCart.push(order);
			}
		}
		
		console.log(JSON.stringify($scope.myCart));
		
		
		
	};
			
			
				
		
	$scope.searchItem = function (keyword) {
		
		$scope.hideItemView=false;
		$scope.hideCartView=true;
		
		var matchItems=[];
		
		for(var i =0 ;i <$scope.allItems.length;i++){
			
			if($scope.allItems[i].group_name.indexOf(keyword)>-1) {matchItems.push($scope.allItems[i]) ;continue;};
			if($scope.allItems[i].name.indexOf(keyword)>-1) {matchItems.push($scope.allItems[i]) ;continue; };
			if($scope.allItems[i].desc.indexOf(keyword)>-1) {matchItems.push($scope.allItems[i]) ;continue; };
			
			
			var isMatch=false;
			for(var j =0 ;j <$scope.allItems[i].styles.length;j++){
				if($scope.allItems[i].styles[j].name.indexOf(keyword)>-1) {isMatch=true ;break; };
			}	
			if(isMatch==true) {matchItems.push($scope.allItems[i]) ;continue; };
		}
		
		$scope.filterItems = angular.copy(matchItems);
		
	    
    };
			
	$scope.back = function () {
		$scope.hideItemView=false;
		$scope.hideCartView=true;
		
    };
    	
	$scope.showMyCart = function () {
		
		
		$scope.hideItemView=true;
		$scope.hideCartView=false;
	
    };
		
		
	
		
		
		
 
 
 
}]);