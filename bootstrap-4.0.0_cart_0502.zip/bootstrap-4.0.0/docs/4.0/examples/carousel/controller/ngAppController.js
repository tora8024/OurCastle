


var ngApp = angular.module('ngApp', []); 
ngApp.controller('ngAppController', ['$scope', function($scope) {
	
	var appCtrl =this;
	$scope.keyword="";
	$scope.userId="";
	$scope.hideCartView=true;
	
	$scope.filterItems = [];
	$scope.myCart=[];
	
	
	
	
  	$scope.allItems = [{
				  "master_id": "00001",
				  "name": "1guitar",
				  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
			},{
				  "master_id": "00002",
				  "name": "2guitar",
				  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
			},{
				  "master_id": "00003",
				  "name": "3guitar",
				  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
			},{
				  "master_id": "00004",
				  "name": "4guitar",
				  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
			},{
				  "master_id": "00005",
				  "name": "5guitar",
				  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
			},{
				  "master_id": "00006",
				  "name": "6guitar",
				  "image": "./img/FtrAcorsticguitar_Remake_0_0.png"
			}
				]; 
				
				
		
	$scope.init = function ($scope) {
	    $scope.filterItems = []; //angular.copy($scope.allItems); 
    };
		
		
		
	$scope.showMyCart = function () {
		
		
		$scope.hideItemView=true;
		$scope.hideCartView=false;
		
	
    };
		
	$scope.showHome = function () {
		
		
		$scope.hideItemView=false;
		$scope.hideCartView=true;
		
	
    };	
    
    
			
	$scope.addToCart = function ($event, item) {
		
		
		var master_id = item.master_id;
		var name = item.name;
		var image = item.image;
		
		var objId = '#'+item.master_id;
		
				
		
		var order={
				  "master_id": master_id,
				  "name": name,
				  "image":image,
			      "amount": 1
			};
		
		
		
		if ($scope.myCart.length ==0){
			$scope.myCart.push(order);
		}else{
			
			var isMatch=false;
			for(var i =0 ;i <$scope.myCart.length;i++){
				if(master_id==$scope.myCart[i].master_id){
					$scope.myCart[i].amount=$scope.myCart[i].amount +1;
					isMatch=true;
					break;
				}
			}
			if(isMatch==false){
				$scope.myCart.push(order);
			}
		}
		
		console.log(JSON.stringify($scope.myCart));
		
		
		
	};
	
	$scope.deleteItem = function ($event, item) {
		
		var newMyCart=[];
		var master_id=item.master_id;
		for(var i =0 ;i <$scope.myCart.length;i++){
			if(master_id==$scope.myCart[i].master_id){
				continue;
			}
			newMyCart.push($scope.myCart[i]);
		}
		$scope.myCart = angular.copy(newMyCart);
		
    };
		
			
			
				
		
	$scope.searchItem = function (keyword) {
		
		if(keyword==undefined || keyword.length==0) {alert('至少輸入一個字元查詢項目'); return};
		
		var matchItems=[];
		
		for(var i =0 ;i <$scope.allItems.length;i++){
			
			if($scope.allItems[i].master_id.indexOf(keyword)>-1) {matchItems.push($scope.allItems[i]) ;continue; };
			if($scope.allItems[i].name.indexOf(keyword)>-1) {matchItems.push($scope.allItems[i]) ;continue; };
				
		}
		
		if(matchItems.length==0) {alert('查無相符的項目'); return};
		
		$scope.filterItems = angular.copy(matchItems);
		
	    
    };
		
	$scope.copy = function () {	
		document.getElementById("result").select();
	    document.execCommand('copy');
	};
		
		
	$scope.printOrder = function () {
		
		var result= "";
		if($scope.userId==''){
			alert('請輸入User ID');
			return;
		}
		
		if($scope.myCart.length==0){
			alert('目前無任何購物項目');
			return;
		}
		
		result= "User ID: " + $scope.userId +"\n";
		
		
		
		var zeroAmountRecord="";
		
		for(var i =0 ;i <$scope.myCart.length;i++){
			
			if( undefined ==$scope.myCart[i].amount ||  ''==$scope.myCart[i].amount || 0==parseInt($scope.myCart[i].amount)  ){
				zeroAmountRecord=zeroAmountRecord+$scope.myCart[i].name+',';
			}else{
				var amount =parseInt($scope.myCart[i].amount);
				for(var x=0;x<amount;x++){
					result= result+$scope.myCart[i].master_id+ " \t "+$scope.myCart[i].name +" \t \n";		
				}
				
			}
				
			
		}
		
		
		if(zeroAmountRecord.length>0){
			alert(zeroAmountRecord+'請選擇購買數量');
			return;
		}
		
		
		
		$scope.result=result;
				
		
		setTimeout(function() {$scope.copy();	}, 1000);

    };
		
	$scope.copy = function () {	
		document.getElementById("result").select();
	    document.execCommand('copy');
	    alert("Copied");
	};
		
 
 
 
}]);
